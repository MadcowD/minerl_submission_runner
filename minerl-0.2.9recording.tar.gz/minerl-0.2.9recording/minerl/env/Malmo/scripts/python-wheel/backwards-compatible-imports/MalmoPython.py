from malmo.MalmoPython import *
