import sys
from malmo.run_mission import run

if __name__ == "__main__":
    run(sys.argv)

