The folder contains a repository of tasks (missions) in Malmo. 
- MalmoMissionTable_CurrentTasks_2016_06_14.pdf: a description of the tasks.
- *.xml: All missions are .xml files. 

To explore the sample missions, see Python_Examples/sample_missions_loader.py.
