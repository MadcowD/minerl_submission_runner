# Where are the ROMS? #

We do not distribute them. A good resource for downloading them can be found here:
http://www.atarimania.com/rom_collection_archive_atari_2600_roms.html

----

Note that the ROM will need to be named correctly in order for the ALE to work with it - eg "montezuma_revenge", "private_eye" etc. To find the right name, look for the `const char* rom() const` method in the corresponding game in https://github.com/mgbellemare/Arcade-Learning-Environment/tree/master/src/games/supported